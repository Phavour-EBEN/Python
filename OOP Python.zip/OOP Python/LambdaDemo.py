# (lambda parameter : expression)(args)

add = lambda a,b : a+b
print(add(5,6))

# Higher order fun

high_order = lambda x,fun : x+fun(x)
print(high_order(20,lambda x:x*x))

print((lambda x : ( x%2 and 'old' or 'even'))(72))

sub_string = lambda string: string in "welcome to ptyhon tutorials"
print(sub_string("to"))
print("*"*20)
# using maps

num = [10,40,56,2,39,15,70,9]
double = list(map(lambda x:x*2,num))
print(double)

cube = list(map(lambda y:y**3,num))
print(cube)


add = lambda x : x +15
print(add(25))

multiply = lambda x,y : x*y
print(multiply(5,5))
print("*"*20)

tuples = [('English',88),('science',90),('maths',97),('social science',82)]
print(f"original tuple: {tuples}")

tuples.sort(key=lambda x:x[1])
print(tuples)

# mine = input("Something: ")
# search = (lambda x:x)(mine.startswith("ohk"))
# print(search)/

ori_list = [12,0,None,-55,45,None,2,6,None,5]

new_list = list(filter(lambda x,:x!=None,ori_list))
print(new_list)