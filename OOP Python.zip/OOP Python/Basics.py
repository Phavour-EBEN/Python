import turtle
import calendar
a = 5
print(a)

b= "hello"
print(b)
crdit_card = 125465
print(crdit_card)

quazy_turtle = turtle.Turtle()
# quazy_turtle.speed(5)
# makng it a function
"""
def square():
    quazy_turtle.forward(100)
    quazy_turtle.right(90)
    quazy_turtle.forward(100)
    quazy_turtle.right(90)
    quazy_turtle.forward(100)
    quazy_turtle.right(90)
    quazy_turtle.forward(100)

# square()
# quazy_turtle.forward(100)
# square()
"""
"""
def circle():
    quazy_turtle.circle(22.7,7.0,50)

circle()
"""
"""
#Calender module
cal = calendar.weekheader(3)
print(cal)
cal_month = calendar.month(2024,1,w=3)
print(cal_month)
day_of_the_week = calendar.weekday(2024,1,27)
print(day_of_the_week)
"""
# If-else statement
# ele = 10
# ant = .001
# if ele > ant:
#     square()
# else:
#     quazy_turtle.forward(100)

# for loops
"""
for i in range(4):
    square()
"""
print(float(1))
list_1 = [1,2,3,4]
print(list_1)
list_2 = [1,"world","skan",4.3,True,list_1]
print(list_2[5][1])
list_1.reverse()
print(list_1)
for each_element in list_2:
    print(each_element)
# sliding
print(list_2[-0:-1:-2])