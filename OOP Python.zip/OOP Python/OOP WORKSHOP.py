"""
import employee
employee.EmployeID()
print(employee.Age)

#EMPTY OBJECT
class EmpObj:
    pass
obj = EmpObj()
obj.x = "hello, world"
print(obj.x)

tupl = ("tuple","is","an","immutable","list")
print(type(tuple)

topics = {"c++","c#","java","python"}
team = {'Developer', 'Content Writer', 'Editor','Tester'}
group = topics.union(team)


grps = topics.intersection(team)
diff = topics.difference(team)
#print(grps)
#print(diff)

set1 = set()
set2 = set()
for i in range(0,9):
    set1.add(i)
for j in range(2,5):
    set2.add(j)

#print(set1)
#print(set2)

set3 = set1 |set2
print(set3)
if set3.issuperset(set1):
    print("hello")
elif set1.issubset(set2):
    print("hi")
else:
    set1 == set2

def display_message(fname):
    print(f"hello {fname},I have learnt "
          f"that People sometimes speak \nof arguments and parameters "
          f"interchangeably.\nSo we are not to be surpriced ")

display_message("SIR")

def describe_cities(city_name,country):
    print(f"{city_name} is the name of a city and is in {country}")


describe_cities("abujah","Nageria")
describe_cities("anaji","Ghana")
describe_cities("London","English")
describe_cities("tokyo","Japan")


#def make_album("Nipa:Esther",""):
d =dict()
d["yam"] = 2
d["rice"] = 3
d["tomato"] = 1
for (k,s) in d.items():
    print(k,s)

tmp = list()
for k, v in d.items():
    tmp.append((v,k))

print(tmp)
"""
from os import name

#first oriented programming
"""
class PartyAnimal:
    x =0

    def party(self):
        self.x = self.x +2
        print("so far",self.x)

an = PartyAnimal()
an.party()
an.party()
an.party()
an.party()
an.party()

class Dog:
    attr1 = "mammal"
    attr2 = "blue_eye"

    def fun(self):
        print("I am a",self.attr1)
        print("I am a",self.attr2)

bunno = Dog()
bunno.fun()

#class GFG
class GFG:
    def __init__(self,name,company):
        self.name = name
        self.company = company

    def show(self):
        print("Hello my name is "+self.name+" and I work at "+self.company+".")

obj = GFG("Joel","Umat")
obj.show()

#Classess and objects
class Person:
    def set_details(self,name,age):
        self.name = name
        self.age = age

    def display(self):
        print("hello I am "+self.name +", a friend")

    def greet(self):
        if self.age > 25:
            print("please how sre you doing ?")
        else:
            print("how do you do ?")


p1 = Person()
p2 = Person()

p1.set_details("jim",18)
p2.set_details("tom",25)

p1.display()
p1.greet()

p2.display()
p2.greet()

print(p2.name)
print(p2.age)

print(p1.name)
print(p1.age)

#practical exercise 1
class Bank_account:
    def set_details(self,name,balance):
        self.name = name
        self.balance =0

    def display(self):
        print(self.name)
        print(self.balance)

    def withdraw(self,amount):
        #self.amount = 90
        print(self.balance-self.amount)
    def deposite(self,amount):
        print(self.amount+self.balance)


bank1=Bank_account()
bank2=Bank_account()

bank1.set_details("Eben",200)
bank2.set_details("Eben",200)

bank1.display()
bank2.display()

bank1.withdraw(100)
bank2.withdraw(500)

bank1.deposite()
bank2.deposite()


class BankAccount:
    def set_details(self, name, balance=0):
        self.name = name
        self.balance = balance

    def display(self):
         print(self.name, self.balance)

    def withdraw(self, amount):
        self.balance -= amount

    def deposit(self, amount):
        self.balance += amount

a1 = BankAccount()
a1.set_details('Mike', 200)

a2 = BankAccount()
a2.set_details('Tom',200)

a1.display()
a2.display()

a1.withdraw(100)
a2.deposit(500)

a1.display()
a2.display()

a1.deposit(300)
a2.withdraw(300)

a1.display()
a2.display()

#Data hiding
class Product:

    def __init__(self):
        self.data1 = 10
        self.__data2 = 20

    def methodA(self):
        print("hey")

    def __methodB(self):
        print("hello")

p = Product()

print(p._Product__methodB())

#Property
class Product:

    def __init__(self,x,y):
        self._x = x
        self._y = y

    def display(self):
        print(self._x,self._y)

    @property
    def valve(self):
        return self._x

    #Assigning valves
    @valve.setter
    def valve(self,val):
        self._x = val

    @property
    def y(self):
        return self._y

    #Assigning valves
    @y.setter
    def y(self,val):
        self._y = val

p = Product(15,20)
p.valve = 12
p.y = 30
print(p.valve)
print(p.y)

class Person:
    def __init__(self,name,age):
        self.name = name
        self.age = age

    def display(self):
        print(self.name,self.age)

    @property
    def age(self):
        return self.age





class Martian:
     #Some who live on Mars.

    def __init__(self, fn, ln):
        self.first_name = fn
        self.last_name = ln

    def __setattr__(self, name, value):
        print(f"you set {name} = {value}")

m =# Martian("Maa","daa")

class buy:
    def total_price(self,quantity,price):
        return quantity * price



Item = buy()
Item.name = "phone"
Item.price = 500
Item.quantity = 6
print(Item.total_price(Item.quantity,Item.price))
"""
"""
#practical exe
class BankAccount:
    def __init__(self,name,balance = 0):
        self.name = name
        self.balance = balance

    def display(self):
         print(self.name, self.balance)

    def withdraw(self, amount):
        self.balance -= amount

    def deposit(self, amount):
        self.balance += amount

a1 = BankAccount("mike",200)

a2 = BankAccount("Tom",200)

a1.display()
a2.display()

a1.withdraw(100)
a2.deposit(500)

a1.display()
a2.display()

a1.deposit(300)
a2.withdraw(300)

a1.display()
a2.display()

class Book:
    def __init__(self,isbn,title,author,publisher,pages,price,copies):
        self.isbn = isbn
        self.title = title
        self.author = author
        self.publisher = publisher
        self.pages = pages
        self.price = price
        self.copies = copies

    def display(self):
        print(f"Title :{self.title}")
        print(f"ISBN: {self.isbn}")
        print(f"Price: {self.price}.")
        print(f"Number of copies: {self.copies}")
        print("."*40)


    def in_stock(self):
        if self.copies > 0:
            return True
        else:
            return False

    def sell(self):
        if self.in_stock():
            self.copies -= 1
        else:
            print("The book is out of stock")

    @property
    def price(self):
        return self.price

    @price.setter
    def price(self,new_price):
        if 50 <= new_price <= 1000:
            self.price = new_price
        else:
            raise ValueError("price of a book cannot be less than 50 or more than 1000.")



book1 = Book('957-4-36-547417-1', 'Learn Physics','Stephen', 'CBC', 350, 200,10)
book2 = Book('652-6-86-748413-3', 'Learn Chemistry','Jack', 'CBC', 400, 220,20)
book3 = Book('957-7-39-347216-2', 'Learn Maths','John', 'XYZ', 500, 300,5)
book4 = Book('957-7-39-347216-2', 'Learn Biology','Jack', 'XYZ', 400, 200,6)

book1.display()
book2.display()
book3.display()
book4.display()

books =[book1,book2,book3,book4]
for book in books:
    book.display()

Jack_list = [book.title for book in books if book.author == 'Jack' ]
print(Jack_list)

print(book2.price)

class Fraction:
    def __init__(self, nr, dr=1):
        self.nr = nr
        self.dr = dr
        if self.dr < 0:
            self.nr *=-1
            self.dr *=-1



    def show(self):
        print(f"The value of the numerator: {self.nr}")
        print(f"The value of the denominator: {self.dr}")
        print(self.nr/self.dr)

    def multiply(self):
        product = (self.nr / self.dr) * (self.nr / self.dr)
        prod = 5*(self.nr / self.dr)
        return product, prod



    def add(self):
        add = (self.nr/self.dr)+(self.nr/self.dr)

exe = Fraction(5,20)
exe.show()

exe_2 = Fraction(8,-2)
exe_2.show()

exe_3 = Fraction(2,-3)
exe_3.show()

print(exe_3.multiply())


class Myclass():
    a = 5

    def __init__(self,x):
        self.x = x

    def method1(self):
        print(self.x)

    @classmethod
    def method2(cls):
        print(cls.a)

Myclass.method2()

class Person:
    species = "Homo sapiens"
    count = 0

    def __init__(self,name,age):
        self.name = name
        self.age = age
        Person.count +=1

    def display(self):
        print(f"{self.name} is {self.age} ears old")

    @classmethod
    def show_count(cls):
        print(f"There are {cls.count}  {cls.species}")


Person.show_count()
p1 = Person ('John',20)
p2 = Person('frank',50)
p3 = Person('doe',10)
p1.display()
Person.show_count()
Person.show_count()

#class method
class Person:

    def __init__(self,name,age):
        self.name = name
        self.age = age

    def display(self):
        print("I am ", self.name, self.age, "years old")

    @classmethod
    def from_str(cls,s):
        name,age =s.split(',')
        return cls(name,age)

    @classmethod
    def from_dict(cls,d):
        return cls(d['name'],d['age'])

p1 = Person ('John',20)
p2 = Person('frank',50)

s="jim,15"
p3 = Person.from_str(s)
p3.display()
d = {'name':'Jane','age':24}
p4 = Person.from_dict(d)
p4.display()
#stativ methods
"""




