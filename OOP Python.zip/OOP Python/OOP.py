"""
class Country:
    isAlive = True
    #Properties are name,flag,language,anthem
    def __init__(self,name):
        self.name = name
        #self.flag = flag

countryone = Country("Ghana")
countrytwo = Country("Japan")
print(countryone.name)
print(countryone.isAlive)
print(countrytwo.name)

#Abstration(Hiding certian info)
class Animal:
    def __init__(self,name,fur):
        self.name = name
        self.fur = fur

class Dog(Animal):



    def alive(self):
        pass

    def eat(self):
        pass

class Dog:
    def barks(self):
        pass


class Cat:
    def purr(self):
        pass



class Shape:
    def __init__(self):
        self.area = 0

    def cal_area(self):
        print(self.area)


class Square(Shape):
    def __init__(self,lenght):
        super().__init__()
        self.lenght = lenght

    def cal_area(self):
        self.area = self.lenght ** 2
        print(self.area)


rec = Shape()
rec.cal_area()


re = Square(5)
re.cal_area()
"""

class Parent:
    def __init__(self,name,age):
        self.name = name
        self.age = age
        #print("This a parent class")

    def greet(self):
        print("Hello ,What's up ")


class Child(Parent):
    def __init__(self,name,age,school,classes):
        super().__init__(name,age)
        self.school = school
        self.classes = classes

    def greet(self):
        print("Please ,Good morning")

mary =Parent("James",20)
mary.greet()

John = Child("nana",14,"umat","ce")
John.greet()
#Encalsulation
class Parent:
    def __init__(self,name,age):
        self.name = name
        self.age = age
        #print("This a parent class")

    def greet(self):
        print("Hello ,What's up ")


class Child(Parent):
    def __init__(self,name,age,school,classes):
        super().__init__(name,age)
        self.school = school
        self.classes = classes

    def greet(self):
        print("Please ,Good morning")

    def allowance(self):
        print(f"{self.name}'s allowance is ")

mary =Parent("James",20)
mary.greet()

John = Child("nana",14,"umat","ce")
John.greet()





