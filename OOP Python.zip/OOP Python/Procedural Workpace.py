"""
#List comprehension
movies = [("citizen kane",1941),("spirited away",2001),("Its a wounderful life",1946),("gattaca",1997),("the aviator",2004),("raiders of the lost ark",1981)]
mymovies = [title for (title,year) in movies if year >2000 ]
print(mymovies)
"""
#CS50 PROGRAMMING
class Student:
    ...

def main():
    student = get_student()
    if student.name=="Padma":
        student.house="town"
    print(f"{student.name} from {student.house}")


def get_student():
    student = Student()
    student.name = input("Name: ")
    student.house = input("House: ")
    return student


if __name__ =="__main__":
    main()

"""

class Calculator:
    def __init__(self,num1,num2):
        self.num1 = num1
        self.num2 = num2

    def add(self):
        return (self.num1+self.num2)

    def subtract(self):
        return (self.num2-self.num1)

    def multiply(self):
        return (self.num1*self.num2)

    def divide(self):
        return (self.num2/self.num1)

obj = Calculator(10,94)
print(obj.add())
print(obj.subtract())
print(obj.multiply())
print(obj.divide())
"""