import random

print("Phavour Industries")
print("Guess What is in my head!!!!!\nThe number guessing game ")
print("--"*20)
start_game = ["q","w","e","r","y","u","i","o","p","l","k","j","h","g","f","d","s","a","z","x","c","v","b","n","m",""," "]
start = None
while start != start_game:
    user = input("Press any key to start game or q to quit: ").lower()
    if user == "q":
        print("Goodbye!!!")
        quit()

    elif user in start_game:
        break



max_range = input("Enter the maximum range of number you want to be playing the game\nNote!!!!\nThe larger the range the harder the game: ")
if max_range.isdigit():
    max_range = int(max_range)
    if max_range <= 0:
        print("Please enter a number greater than 0")
        exit()
else:
    print("Please enter a number next time")
    exit()

def guessing_game():

    number = random.randint(0,max_range)
    guess = None
    while guess != number:
        guess =int(input("Enter a number: "))
        if guess < number:
            print("Too low")
        elif guess > number:
            print("Too high")
    print("Yah!!!, \nCongratulations! you guessed my number!")
    exit()

# difficulty()
guessing_game()
