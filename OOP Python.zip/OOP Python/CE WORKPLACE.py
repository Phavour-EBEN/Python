
# ENCRYPTION AND DECRYPTIO OF PASSWORDS
"""
from cryptography.fernet import Fernet

key = Fernet.generate_key()
crytper = Fernet(key)

# pwd = input("Enter your password: ")
encryt_pwd = crytper.encrypt(input("mes").encode())
# encryt_pwd = crytper.encrypt(pwd.encode())
# print(key)
print(encryt_pwd)

decryt_pwd = crytper.decrypt(encryt_pwd).decode()
# print(str(encryt_pwd, 'utf8'))
# print(str(decryt_pwd, 'utf8'))
print(decryt_pwd)

"""
"""
def name_programme():
    name=input("enter your name :")
    programme=input("enter your programme :")
    print(f"name:{name} programme:{programme}")

name_programme()

def main():
    fname = input("enter full name: ")
    yprog = input("enter your programme: ")
    return fname ,yprog
fname ,yprog = main()
print("name: ",fname)
print("programme: ",yprog)

def multiply(*nums):
    total = 1
    for num in nums:
        total *=num
    return total
print(multiply(2,5,4,7))



def play(input):
    if (input %3 ==0) and (input %5 ==0):
        return "fizzbuzz"
    if input %3==0:
        return "fizz"
    if input %5==0:
        return "buzz"
    return input


print(play(15))

L1 = [100,900,300,400,500]
START = 1
SUM = 0
for C in range(START,4):
    SUM = SUM + L1[C]
    print(C,":",SUM)
    SUM = SUM+L1[0]*10
    print(SUM)


def changlist():
    L=[]
    L1=[]
    L2=[]
    for i in range(1,10):
        L.append(i)
        #print(L)
    for i in range(10,1,-2):
        L1.append(i)
        #print(L1)
    for i in range(len(L1)):
        L2.append(L1[i]+L[i])
        L2.append(len(L)-len(L1))
        print(L2)

changlist()


class Homo:
    def speck(self):
        print("hello homo")

class Man(Homo):
    def talk(self):
        print("man can talk")

d = Man()
d.speck()
d.talk()

#Multilevel inheritance
class Homo:
    def speck(self):
        print("hello homo")

class Man(Homo):
    def talk(self):
        print("man can talk")
class Child(Man):
    def eat(self):
        print("child can eat")

ch = Child()
ch.eat()
ch.talk()
ch.speck()

class Person:
    def __init__(self,fname,lname):
        self.fname = fname
        self.lname = lname

    def name(self):
        print(self.fname,self.lname)

class Student(Person):
    def __init__(self,fname,lname):
        super().__init__(fname,lname)

cl  = Student("John","Doe")
cl.name()

class Cal1:
    def sum(self,a,b):
        return a+b

class Cal2:
    def mul(self,a,b):
        return a*b

class obtain(Cal1,Cal2):
    def div(self,a,b):
        return a/b

c=obtain()
print(issubclass(obtain,Cal1))
print(issubclass(obtain,Cal2))
print(issubclass(Cal2,Cal1))


class Restaurant:
    def __init__(self,name,cuisine_type):
        self.name = name
        self.cuisine_type = cuisine_type

    def describe_restaurant(self):
        print(f"Welcome to {self.name} Restaurant")
        print(f"Here in {self.name} Restaurant we serve {self.cuisine_type} foods of all kinds")

    def open_restaurant(self):
        print(f"{self.name} restaurant is now opened")

res1 = Restaurant("brown","local")
print(f"Name : {res1.name}")
print(f"Cuisine_type : {res1.cuisine_type}")
res1.describe_restaurant()
res1.open_restaurant()

res2 = Restaurant("Delicious kokoo","local")
print(f"Name : {res2.name}")
print(f"Cuisine_type : {res2.cuisine_type}")
res2.describe_restaurant()
res2.open_restaurant()

res3 = Restaurant("macDonzy","chainse")
print(f"Name : {res3.name}")
print(f"Cuisine_type : {res3.cuisine_type}")
res3.describe_restaurant()
res3.open_restaurant()

class User:
    def __init__(self,FirstName,LastName,Username,location):
        self.FirstName = FirstName
        self.LastName = LastName
        self.Username = Username
        self.location = location
        self.age = 0

    def describe_user(self):
        print(f"Name :{self.FirstName}")
        print(f"Name :{self.LastName}")
        print(f"Name :{self.Username}")
        print(f"Name :{self.location}")


    def your_age(self):
        print(f"Age is {self.age}")

    def updated_age(self,newage):
        self.age = newage

    def greet_user(self):
        print(f"Howdy {self.Username} !".upper())

user = User("John","Koffie","phavour","washington dc")
user.describe_user()
user.greet_user()
user.updated_age(25)
user.your_age()

"""


# class Car:
#     """A simple attempt to represent a car."""
#
#     def __init__(self, make, model, year):
#         """Initialize attributes to describe a car."""
#         self.make = make
#         self.model = model
#         self.year = year
#         self.odometer_reading = 23
#
#     def get_descriptive_name(self):
#         """Return a neatly formatted descriptive name."""
#         long_name = f"{self.year} {self.make} {self.model}"
#         return long_name.title()
#
#     def read_odometer(self):
#         read = f"There is {self.odometer_reading}  odometer reading on the car"
#         return read
#
#     def update_reading(self,miles):
#
#         if miles >= self.odometer_reading:
#             self.odometer_reading=miles
#         else:
#             print("you can not change odometer readings")
#
#
#
# my_new_car = Car('audi', 'a4', 2019)
# print(my_new_car.get_descriptive_name())
#
#
# my_new_car.update_reading(19)
# print(my_new_car.read_odometer())
#


# class Restaurant():
#     """A class representing a restaurant."""
#
#     def __init__(self, name, cuisine_type):
#         """Initialize the restaurant."""
#         self.name = name.title()
#         self.cuisine_type = cuisine_type
#
#     def describe_restaurant(self):
#         """Display a summary of the restaurant."""
#         msg = self.name + " serves wonderful " + self.cuisine_type + "."
#         print("\n" + msg)
#
#     def open_restaurant(self):
#         """Display a message that the restaurant is open."""
#         msg = self.name + " is open. Come on in!"
#         print("\n" + msg)
#
# restaurant = Restaurant('the mean queen', 'pizza')
# print(restaurant.name)
# print(restaurant.cuisine_type)
#
# restaurant.describe_restaurant()
# restaurant.open_restaurant()
#
# class IceCreamStand(Restaurant):
#     def __init__(self,name,cuisine_type="IceCream"):
#         super().__init__( name, cuisine_type)
#         self.flavors = []
#
#     def display(self):
#         self.flavors = ["vanila","strew-berry","chocolate"]
#         for flavors in self.flavors:
#             print(flavors)
#
# ice = IceCreamStand("The big one")
# ice.display()
#
# from cryptography.fernet import Fernet
# import maskpass
# import base64
#
# name = input("password: ")
# enco_name = base64.b64encode(name.encode("utf-8"))
# print(enco_name)

"""Lambda functions"""
# print((lambda a, b: a*b)(5,5))
#
# add =(lambda a, b: a*b)
# print(add(5,5))
#
# addd = lambda x,y = 15,z = 10 : x+y+z
# print(addd(5))
#
# addition = lambda *args : sum(args)
# print(addition(1,1,1,1,1))
#
# lam = lambda x :(x %2 and 'old' or 'even')
# print(lam(10))
#
# sub = lambda string : string in 'welcome to python tutorials'
# print(sub('java'))
# print(sub('to'))

"""lamdba with filter"""
# num = [10,20,30,40,50,60]
# great = list(filter(lambda num: num>20,num))
# print(great)