import random
import string
"""Getting the length of the password from the user"""
Length_Of_Password = int(input("Enter the length of your password: "))

"""Getting the user to choice what should be inclue in the password"""
print("Choose your character set "
      "\n1. Letters"
      "\n2. Digits"
      "\n3. Special Characters"
      "\n4. Exit")

character_set = ""
while True:
    choice = int(input("Pick a number to include that set into your password: "))
    if choice == 1:
        character_set += string.ascii_letters
    elif choice == 2:
        character_set += string.digits
    elif choice == 3:
        character_set += string.punctuation
    elif choice == 4:
        break
    else:
        print("Invalid input. Please pick from the options")


password = []
for i in range(Length_Of_Password):
    random_password = random.choice(character_set)
    password.append(random_password)

print("".join(password))