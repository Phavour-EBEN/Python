class Resturant:
    def __init__(self,name,manager,location,hours_of_work,contact):
        self.name = name
        self.manager = manager
        self.location = location
        self.hours_of_work = hours_of_work
        self.contact = contact
#displaying the information about the resturant
    def display(self):
        print(f"Name Of Resturant: {self.name}")
        print(f"Manager Of The Resturant: {self.manager}")
        print(f"Location: {self.location}")
        print(f"Hours Of Works: {self.hours_of_work}")
        print(f"Contact: {self.contact}")

    def _str_(self):
        return f"{self.name}"

"""

class Menu:
    def fd(self):
        food ={'main':['plain rice','jollof rice','fufu','banku'],
                    'pizza':['meat pizza','chicken pizza'],
                    'beverages':['malta guinness','coca-cola','star','tequila']}
        pass


class Customers(Resturant,Menu):
    super().__init__()
    super().__init__()
    def __init__(self,prompt):
        self.name = input("Please enter your name: ")
        self.location = input("Please enter your location: ")
        self.prompt = int(input("Enter 1 to display menu: ",prompt))
        if self.prompt == 1:
            Customers.






"""

resturant = Resturant("Brown's Resturant","Steve Doe","Opposite Tarkwa Regional Hospital",{"Monday-Friday":"8:00 AM-11:00 PM"},"+233-559-662-971")

resturant.display()
